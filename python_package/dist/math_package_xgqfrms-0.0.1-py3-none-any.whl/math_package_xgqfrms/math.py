#!/usr/bin/env python3

# coding: utf8

print("xgqfrms's first Python 3 Project Package `math_package_xgqfrms` ✅")

# addition
def add(n1, n2):
  return n1 + n2

# subtraction
def sub(n1, n2):
  return n1 - n2

# multiplication
def mul(n1, n2):
  return n1 * n2

# division
def div(n1, n2):
  return n1 / n2

# n1 = 1
# n2 = 2
# sum = add(n1, n2)
# print("sum =", sum)
# sum = 3

# n1 = 3
# n2 = 1
# minus = sub(n1, n2)
# print("minus =", minus)
# minus = 2

# n1 = 2
# n2 = 3
# multi = mul(n1, n2)
# print("multi =", multi)
# multi = 6

# n1 = 6
# n2 = 2
# divide = div(n1, n2)
# print("divide =", divide)
# div = 3.0

# python3 ./src/math_package_xgqfrms/math.py
