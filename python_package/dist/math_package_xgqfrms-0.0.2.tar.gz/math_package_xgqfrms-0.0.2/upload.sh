#!/usr/bin/env bash

# upload
python3 -m twine upload dist/*

echo "upload ✅"
