#!/usr/bin/env bash

# build
python3 -m build

echo "build ✅"
